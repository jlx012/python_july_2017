# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from datetime import *

from django.shortcuts import render


def index(request):
    date = datetime.now()

    context = {
        'date': date,
    }
    return render(request,'time_display/index.html', context)

# Create your views here.
