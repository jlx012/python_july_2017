# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect

def index(request):

    return render(request, 'surveyform/index.html')

def result(request):
    if 'counter' not in request.session:
        request.session['counter'] = 0
    if 'name' not in request.session:
        request.session['name'] = request.POST['name']
    if 'location' not in request.session:
        request.session['location'] = request.POST['location']
    if 'language' not in request.session:
        request.session['language'] = request.POST['language']
    if 'comment' not in request.session:
        request.session['comment'] = request.POST['comment']
    request.session['counter'] += 1
    context = {
        'name': request.session['name'],
        'location': request.session['location'],
        'language': request.session['language'],
        'comment': request.session['comment'],
        'counter': request.session['counter'],
    }
    return render(request, 'surveyform/result.html', context)
