# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect
from random import randint
from datetime import *

def index(request):
    if 'count' not in request.session:
        request.session['count'] = 0

    if 'activities' not in request.session:
        request.session['activities'] = []

    if 'farm' in request.POST:
        something = randint(10,21)
        phrase = 'Entered a casino and lost {} golds... Ouch.. {}'.format(something, datetime.now())
        request.session['activities'].insert(0, phrase)
        request.session['count'] += something

    elif 'cave' in request.POST:
        something = randint(5,11)
        phrase = 'Entered a casino and lost {} golds... Ouch.. {}'.format(something, datetime.now())
        request.session['activities'].insert(0, phrase)
        request.session['count'] += something

    elif 'house' in request.POST:
        something = randint(2,6)
        phrase = 'Entered a casino and lost {} golds... Ouch.. {}'.format(something, datetime.now())
        request.session['activities'].insert(0, phrase)
        request.session['count'] += something

    elif 'casino' in request.POST:
        something = randint(-50,51)
        if something < 0:
            phrase = 'Entered a casino and lost {} golds... Ouch.. {}'.format(something, datetime.now())
            request.session['activities'].insert(0, phrase)
        else:
            phrase = 'Earned {} golds from the farm! ({})'.format(something, datetime.now())
            request.session['activities'].insert(0, phrase)
        request.session['count'] += something


    context = {
        'count': request.session['count'],
        'activities': request.session['activities'],
    }

    return render(request, 'ninja_gold/index.html', context)

def process_money(request):

    return redirect('/')
